//
//  an_main.h
//  AntinatText
//
//  Created by LEI on 12/20/15.
//  Copyright © 2015 TouchingApp. All rights reserved.
//

#ifndef an_main_h
#define an_main_h

int
an_setup (const char *config_content, int config_content_size);

int
an_main ();

void
closeup (int x);

#endif /* an_main_h */
